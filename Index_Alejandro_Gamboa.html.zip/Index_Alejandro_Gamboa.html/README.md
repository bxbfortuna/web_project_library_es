La biblioteca triple peaks de triple ten fue creada con ayuda de html y css, con apoyo de chat gpt 4.0 para el formateo del codigo y la configuración de flexbox
